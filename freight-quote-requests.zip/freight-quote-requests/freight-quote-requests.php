<?php
/**
 * Plugin Name: Freight Quote Requests
 * Description: Freight quote request form ([freight_quote_form]) that saves every request to the database, emails your team, and lets you manage and price requests in wp-admin. Supports English and Russian.
 * Version: 1.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: fqr
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class FQR_Plugin {

	const VERSION    = '1.1.0';
	const DB_VERSION = '2';
	const OPT        = 'fqr_settings';

	/** Current language for rendering: 'en' or 'ru'. */
	private static $lang = 'en';

	public static function init() {
		register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_upgrade' ) );
		add_shortcode( 'freight_quote_form', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_fqr_submit', array( __CLASS__, 'ajax_submit' ) );
		add_action( 'wp_ajax_nopriv_fqr_submit', array( __CLASS__, 'ajax_submit' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
	}

	/* ------------------------------------------------------------------
	 * Translations (EN is the source text, RU is looked up here)
	 * To add a string: add 'English text' => 'Russian text' below.
	 * ----------------------------------------------------------------*/

	private static function ru() {
		static $d = null;
		if ( null !== $d ) {
			return $d;
		}
		$d = array(
			// Form.
			'Shipment' => 'Перевозка',
			'Freight type' => 'Тип перевозки',
			'Preferred pickup date' => 'Желаемая дата забора',
			'From' => 'Откуда',
			'To' => 'Куда',
			'Country' => 'Страна',
			'City' => 'Город',
			'Postcode' => 'Почтовый индекс',
			'Packages' => 'Грузовые места',
			'(weight in kg, size in cm, per piece)' => '(вес в кг, размеры в см, на 1 место)',
			'+ Add another package type' => '+ Добавить ещё место',
			'Cargo description' => 'Описание груза',
			'e.g. Furniture on pallets' => 'напр. мебель на паллетах',
			'Additional services' => 'Дополнительные услуги',
			'Your contact details' => 'Ваши контактные данные',
			'Name' => 'Имя',
			'Company' => 'Компания',
			'Email' => 'Эл. почта',
			'Phone' => 'Телефон',
			'Comments' => 'Комментарии',
			'I agree that my data may be used to prepare a quote.' => 'Я согласен(на) на обработку моих данных для подготовки расчёта.',
			'Privacy policy' => 'Политика конфиденциальности',
			'Request a quote' => 'Запросить расчёт',
			// JS.
			'Qty' => 'Кол-во',
			'Weight (kg)' => 'Вес (кг)',
			'Length (cm)' => 'Длина (см)',
			'Width (cm)' => 'Ширина (см)',
			'Height (cm)' => 'Высота (см)',
			'Remove' => 'Удалить',
			'Something went wrong. Please try again.' => 'Что-то пошло не так. Попробуйте ещё раз.',
			'Network error. Please try again.' => 'Ошибка сети. Попробуйте ещё раз.',
			// Freight types.
			'Parcel / Express' => 'Посылка / экспресс',
			'Road freight – groupage (LTL)' => 'Автоперевозка – сборный груз (LTL)',
			'Road freight – full truck (FTL)' => 'Автоперевозка – целая машина (FTL)',
			'Air freight' => 'Авиаперевозка',
			'Sea freight' => 'Морская перевозка',
			'Rail freight' => 'Железнодорожная перевозка',
			// Extras.
			'Tail-lift / liftgate needed' => 'Нужен гидроборт',
			'Customs clearance' => 'Таможенное оформление',
			'Cargo insurance' => 'Страхование груза',
			'Dangerous goods (ADR/IATA)' => 'Опасный груз (ADR/IATA)',
			'Temperature-controlled' => 'Температурный режим',
			'Delivery to residential address' => 'Доставка по жилому адресу',
			// Validation / messages.
			'Your session expired. Please reload the page and try again.' => 'Сессия истекла. Обновите страницу и попробуйте снова.',
			'Too many requests. Please try again later or contact us directly.' => 'Слишком много запросов. Попробуйте позже или свяжитесь с нами напрямую.',
			'Please choose a valid freight type.' => 'Выберите корректный тип перевозки.',
			'Please choose valid origin and destination countries.' => 'Выберите корректные страны отправления и назначения.',
			'Please fill in all required fields.' => 'Заполните все обязательные поля.',
			'Please enter a valid email address.' => 'Введите корректный адрес эл. почты.',
			'Please accept the consent checkbox.' => 'Подтвердите согласие на обработку данных.',
			'Please add at least one package.' => 'Добавьте хотя бы одно грузовое место.',
			'Please check package quantity, weight and dimensions.' => 'Проверьте количество, вес и размеры грузовых мест.',
			'We could not save your request. Please try again or contact us directly.' => 'Не удалось сохранить запрос. Попробуйте ещё раз или свяжитесь с нами.',
			'Thank you! We have received your request and will send you a quote shortly.' => 'Спасибо! Ваш запрос получен, мы скоро отправим вам расчёт.',
			// Customer email.
			'Hello' => 'Здравствуйте',
			'Thank you for your request. We will prepare your quote and get back to you shortly.' => 'Спасибо за ваш запрос. Мы подготовим расчёт и свяжемся с вами в ближайшее время.',
			'We received your quote request' => 'Мы получили ваш запрос на расчёт',
			'Reference' => 'Номер запроса',
			'Pickup date' => 'Дата забора',
			'Cargo' => 'Груз',
			'Totals' => 'Итого',
			'Extras' => 'Доп. услуги',
			'pcs' => 'мест',
			'kg' => 'кг',
			'cm' => 'см',
			'chargeable' => 'тарифицируемый вес',
			// Countries.
			'Albania' => 'Албания', 'Andorra' => 'Андорра', 'Austria' => 'Австрия', 'Belgium' => 'Бельгия',
			'Bosnia and Herzegovina' => 'Босния и Герцеговина', 'Bulgaria' => 'Болгария', 'Croatia' => 'Хорватия',
			'Cyprus' => 'Кипр', 'Czechia' => 'Чехия', 'Denmark' => 'Дания', 'Estonia' => 'Эстония',
			'Finland' => 'Финляндия', 'France' => 'Франция', 'Germany' => 'Германия', 'Greece' => 'Греция',
			'Hungary' => 'Венгрия', 'Iceland' => 'Исландия', 'Ireland' => 'Ирландия', 'Italy' => 'Италия',
			'Kosovo' => 'Косово', 'Latvia' => 'Латвия', 'Liechtenstein' => 'Лихтенштейн', 'Lithuania' => 'Литва',
			'Luxembourg' => 'Люксембург', 'Malta' => 'Мальта', 'Monaco' => 'Монако', 'Montenegro' => 'Черногория',
			'Netherlands' => 'Нидерланды', 'North Macedonia' => 'Северная Македония', 'Norway' => 'Норвегия',
			'Poland' => 'Польша', 'Portugal' => 'Португалия', 'Romania' => 'Румыния', 'San Marino' => 'Сан-Марино',
			'Serbia' => 'Сербия', 'Slovakia' => 'Словакия', 'Slovenia' => 'Словения', 'Spain' => 'Испания',
			'Sweden' => 'Швеция', 'Switzerland' => 'Швейцария', 'Türkiye' => 'Турция',
			'United Kingdom' => 'Великобритания', 'Armenia' => 'Армения', 'Azerbaijan' => 'Азербайджан',
			'Belarus' => 'Беларусь', 'Georgia' => 'Грузия', 'Kazakhstan' => 'Казахстан', 'Kyrgyzstan' => 'Киргизия',
			'Moldova' => 'Молдова', 'Russia' => 'Россия', 'Tajikistan' => 'Таджикистан',
			'Turkmenistan' => 'Туркменистан', 'Ukraine' => 'Украина', 'Uzbekistan' => 'Узбекистан',
			'United States' => 'США', 'Canada' => 'Канада', 'China' => 'Китай',
		);
		return $d;
	}

	/** Translate an English string into the given (or current) language. */
	public static function t( $s, $lang = null ) {
		$lang = $lang ? $lang : self::$lang;
		if ( 'ru' === $lang ) {
			$d = self::ru();
			if ( isset( $d[ $s ] ) ) {
				return $d[ $s ];
			}
		}
		return $s;
	}

	/** Translate + escape for HTML output. */
	private static function h( $s ) {
		return esc_html( self::t( $s ) );
	}

	private static function detect_lang() {
		$l = '';
		if ( function_exists( 'pll_current_language' ) ) {
			$l = (string) pll_current_language();
		} elseif ( defined( 'ICL_LANGUAGE_CODE' ) ) {
			$l = (string) ICL_LANGUAGE_CODE;
		} else {
			$l = (string) determine_locale();
		}
		$l = strtolower( substr( $l, 0, 2 ) );
		$l = apply_filters( 'fqr_lang', $l );
		return ( 'ru' === $l ) ? 'ru' : 'en';
	}

	/* ------------------------------------------------------------------
	 * Setup
	 * ----------------------------------------------------------------*/

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'fqr_requests';
	}

	public static function activate() {
		self::create_table();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'fqr_db_version' ) !== self::DB_VERSION ) {
			self::create_table();
		}
	}

	private static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$table   = self::table();

		// dbDelta is picky: two spaces after PRIMARY KEY, one column per line.
		$sql = "CREATE TABLE $table (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  reference varchar(20) NOT NULL,
  created_at datetime NOT NULL,
  status varchar(20) NOT NULL DEFAULT 'new',
  lang char(2) NOT NULL DEFAULT 'en',
  freight_type varchar(20) NOT NULL,
  origin_country char(2) NOT NULL,
  origin_city varchar(100) NOT NULL DEFAULT '',
  origin_postcode varchar(20) NOT NULL DEFAULT '',
  dest_country char(2) NOT NULL,
  dest_city varchar(100) NOT NULL DEFAULT '',
  dest_postcode varchar(20) NOT NULL DEFAULT '',
  pickup_date date DEFAULT NULL,
  packages longtext NOT NULL,
  total_pieces int(11) NOT NULL DEFAULT 0,
  total_weight_kg decimal(10,2) NOT NULL DEFAULT 0,
  total_volume_m3 decimal(10,4) NOT NULL DEFAULT 0,
  chargeable_weight_kg decimal(10,2) NOT NULL DEFAULT 0,
  cargo_description varchar(255) NOT NULL DEFAULT '',
  extras text NOT NULL,
  contact_name varchar(100) NOT NULL,
  company varchar(150) NOT NULL DEFAULT '',
  email varchar(150) NOT NULL,
  phone varchar(40) NOT NULL DEFAULT '',
  message text NOT NULL,
  quoted_price decimal(12,2) DEFAULT NULL,
  currency char(3) NOT NULL DEFAULT 'EUR',
  admin_notes text NOT NULL,
  ip_address varchar(45) NOT NULL DEFAULT '',
  consent tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY reference (reference),
  KEY status (status),
  KEY created_at (created_at)
) $charset;";

		dbDelta( $sql );
		update_option( 'fqr_db_version', self::DB_VERSION );
	}

	/* ------------------------------------------------------------------
	 * Settings / lookups
	 * ----------------------------------------------------------------*/

	public static function settings() {
		$defaults = array(
			'notify_email'       => get_option( 'admin_email' ),
			'customer_copy'      => 1,
			'volumetric_divisor' => 5000,
			'max_per_hour'       => 5,
			'currency'           => 'EUR',
			'privacy_url'        => '',
			'privacy_url_ru'     => '',
			'success_message'    => 'Thank you! We have received your request and will send you a quote shortly.',
			'success_message_ru' => 'Спасибо! Ваш запрос получен, мы скоро отправим вам расчёт.',
		);
		return wp_parse_args( get_option( self::OPT, array() ), $defaults );
	}

	/** Run labels through the translator (after filters, so custom entries are translated if in the dictionary). */
	private static function translate_list( $list, $lang ) {
		foreach ( $list as $k => $label ) {
			$list[ $k ] = self::t( $label, $lang );
		}
		return $list;
	}

	public static function freight_types( $lang = null ) {
		$list = apply_filters( 'fqr_freight_types', array(
			'parcel' => 'Parcel / Express',
			'ltl'    => 'Road freight – groupage (LTL)',
			'ftl'    => 'Road freight – full truck (FTL)',
			'air'    => 'Air freight',
			'sea'    => 'Sea freight',
			'rail'   => 'Rail freight',
		) );
		return self::translate_list( $list, $lang );
	}

	public static function extras_list( $lang = null ) {
		$list = apply_filters( 'fqr_extras', array(
			'liftgate'    => 'Tail-lift / liftgate needed',
			'customs'     => 'Customs clearance',
			'insurance'   => 'Cargo insurance',
			'dangerous'   => 'Dangerous goods (ADR/IATA)',
			'temp'        => 'Temperature-controlled',
			'residential' => 'Delivery to residential address',
		) );
		return self::translate_list( $list, $lang );
	}

	public static function statuses() {
		return array(
			'new'    => 'New',
			'quoted' => 'Quoted',
			'won'    => 'Won',
			'lost'   => 'Lost',
			'spam'   => 'Spam',
		);
	}

	/** ISO 3166-1 alpha-2 => English name (translated automatically). Extend with the 'fqr_countries' filter. */
	public static function countries( $lang = null ) {
		$c = array(
			// Europe.
			'AL' => 'Albania', 'AD' => 'Andorra', 'AT' => 'Austria', 'BE' => 'Belgium',
			'BA' => 'Bosnia and Herzegovina', 'BG' => 'Bulgaria', 'HR' => 'Croatia', 'CY' => 'Cyprus',
			'CZ' => 'Czechia', 'DK' => 'Denmark', 'EE' => 'Estonia', 'FI' => 'Finland',
			'FR' => 'France', 'DE' => 'Germany', 'GR' => 'Greece', 'HU' => 'Hungary',
			'IS' => 'Iceland', 'IE' => 'Ireland', 'IT' => 'Italy', 'XK' => 'Kosovo',
			'LV' => 'Latvia', 'LI' => 'Liechtenstein', 'LT' => 'Lithuania', 'LU' => 'Luxembourg',
			'MT' => 'Malta', 'MC' => 'Monaco', 'ME' => 'Montenegro', 'NL' => 'Netherlands',
			'MK' => 'North Macedonia', 'NO' => 'Norway', 'PL' => 'Poland', 'PT' => 'Portugal',
			'RO' => 'Romania', 'SM' => 'San Marino', 'RS' => 'Serbia', 'SK' => 'Slovakia',
			'SI' => 'Slovenia', 'ES' => 'Spain', 'SE' => 'Sweden', 'CH' => 'Switzerland',
			'TR' => 'Türkiye', 'GB' => 'United Kingdom',

			// CIS and neighbours.
			'AM' => 'Armenia', 'AZ' => 'Azerbaijan', 'BY' => 'Belarus', 'GE' => 'Georgia',
			'KZ' => 'Kazakhstan', 'KG' => 'Kyrgyzstan', 'MD' => 'Moldova', 'RU' => 'Russia',
			'TJ' => 'Tajikistan', 'TM' => 'Turkmenistan', 'UA' => 'Ukraine', 'UZ' => 'Uzbekistan',

			// Northern America.
			'US' => 'United States', 'CA' => 'Canada',

			// China.
			'CN' => 'China',
		);
		return self::translate_list( apply_filters( 'fqr_countries', $c ), $lang );
	}

	private static function country_name( $code, $lang = null ) {
		$c = self::countries( $lang );
		return isset( $c[ $code ] ) ? $c[ $code ] : $code;
	}

	/* ------------------------------------------------------------------
	 * Front end: shortcode  [freight_quote_form]  or  [freight_quote_form lang="ru"]
	 * ----------------------------------------------------------------*/

	public static function shortcode( $atts = array() ) {
		static $assets_printed = false;

		$atts = shortcode_atts( array( 'lang' => '' ), $atts, 'freight_quote_form' );
		$want = strtolower( trim( $atts['lang'] ) );
		self::$lang = in_array( $want, array( 'en', 'ru' ), true ) ? $want : self::detect_lang();

		$s           = self::settings();
		$privacy_url = ( 'ru' === self::$lang && $s['privacy_url_ru'] ) ? $s['privacy_url_ru'] : $s['privacy_url'];

		ob_start();
		?>
		<form class="fqr-form" method="post" novalidate>
			<input type="hidden" name="action" value="fqr_submit">
			<input type="hidden" name="lang" value="<?php echo esc_attr( self::$lang ); ?>">
			<input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'fqr_submit' ) ); ?>">
			<div class="fqr-hp" aria-hidden="true">
				<label>Website <input type="text" name="fqr_website" tabindex="-1" autocomplete="off"></label>
			</div>

			<fieldset>
				<legend><?php echo self::h( 'Shipment' ); ?></legend>
				<div class="fqr-row">
					<label><?php echo self::h( 'Freight type' ); ?> *
						<select name="freight_type" required>
							<?php foreach ( self::freight_types() as $k => $label ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label><?php echo self::h( 'Preferred pickup date' ); ?>
						<input type="date" name="pickup_date" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>">
					</label>
				</div>
			</fieldset>

			<fieldset>
				<legend><?php echo self::h( 'From' ); ?></legend>
				<div class="fqr-row">
					<label><?php echo self::h( 'Country' ); ?> *
						<select name="origin_country" required><?php echo self::country_options( 'LT' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></select>
					</label>
					<label><?php echo self::h( 'City' ); ?> *<input type="text" name="origin_city" maxlength="100" required></label>
					<label><?php echo self::h( 'Postcode' ); ?><input type="text" name="origin_postcode" maxlength="20"></label>
				</div>
			</fieldset>

			<fieldset>
				<legend><?php echo self::h( 'To' ); ?></legend>
				<div class="fqr-row">
					<label><?php echo self::h( 'Country' ); ?> *
						<select name="dest_country" required><?php echo self::country_options( 'DE' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></select>
					</label>
					<label><?php echo self::h( 'City' ); ?> *<input type="text" name="dest_city" maxlength="100" required></label>
					<label><?php echo self::h( 'Postcode' ); ?><input type="text" name="dest_postcode" maxlength="20"></label>
				</div>
			</fieldset>

			<fieldset>
				<legend><?php echo self::h( 'Packages' ); ?> <small><?php echo self::h( '(weight in kg, size in cm, per piece)' ); ?></small></legend>
				<div class="fqr-packages"></div>
				<button type="button" class="fqr-add"><?php echo self::h( '+ Add another package type' ); ?></button>
				<div class="fqr-row">
					<label class="fqr-wide"><?php echo self::h( 'Cargo description' ); ?> *
						<input type="text" name="cargo_description" maxlength="255" placeholder="<?php echo esc_attr( self::t( 'e.g. Furniture on pallets' ) ); ?>" required>
					</label>
				</div>
			</fieldset>

			<fieldset>
				<legend><?php echo self::h( 'Additional services' ); ?></legend>
				<div class="fqr-checks">
					<?php foreach ( self::extras_list() as $k => $label ) : ?>
						<label><input type="checkbox" name="extras[]" value="<?php echo esc_attr( $k ); ?>"> <?php echo esc_html( $label ); ?></label>
					<?php endforeach; ?>
				</div>
			</fieldset>

			<fieldset>
				<legend><?php echo self::h( 'Your contact details' ); ?></legend>
				<div class="fqr-row">
					<label><?php echo self::h( 'Name' ); ?> *<input type="text" name="contact_name" maxlength="100" required></label>
					<label><?php echo self::h( 'Company' ); ?><input type="text" name="company" maxlength="150"></label>
				</div>
				<div class="fqr-row">
					<label><?php echo self::h( 'Email' ); ?> *<input type="email" name="email" maxlength="150" required></label>
					<label><?php echo self::h( 'Phone' ); ?><input type="tel" name="phone" maxlength="40"></label>
				</div>
				<div class="fqr-row">
					<label class="fqr-wide"><?php echo self::h( 'Comments' ); ?><textarea name="message" rows="3" maxlength="2000"></textarea></label>
				</div>
				<label class="fqr-consent">
					<input type="checkbox" name="consent" value="1" required>
					<?php echo self::h( 'I agree that my data may be used to prepare a quote.' ); ?>
					<?php if ( $privacy_url ) : ?>
						<a href="<?php echo esc_url( $privacy_url ); ?>" target="_blank" rel="noopener"><?php echo self::h( 'Privacy policy' ); ?></a>
					<?php endif; ?> *
				</label>
			</fieldset>

			<button type="submit" class="fqr-submit"><?php echo self::h( 'Request a quote' ); ?></button>
			<div class="fqr-msg" role="status" aria-live="polite"></div>
		</form>
		<?php
		if ( ! $assets_printed ) {
			$assets_printed = true;
			echo self::assets( admin_url( 'admin-ajax.php' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		$html       = ob_get_clean();
		self::$lang = 'en';
		return $html;
	}

	private static function country_options( $selected ) {
		$out = '';
		foreach ( self::countries() as $code => $name ) {
			$out .= sprintf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $code ),
				selected( $selected, $code, false ),
				esc_html( $name )
			);
		}
		return $out;
	}

	private static function assets( $ajax_url ) {
		$i18n = array(
			'qty'     => self::t( 'Qty' ),
			'weight'  => self::t( 'Weight (kg)' ),
			'length'  => self::t( 'Length (cm)' ),
			'width'   => self::t( 'Width (cm)' ),
			'height'  => self::t( 'Height (cm)' ),
			'remove'  => self::t( 'Remove' ),
			'error'   => self::t( 'Something went wrong. Please try again.' ),
			'network' => self::t( 'Network error. Please try again.' ),
		);
		ob_start();
		?>
		<style>
			.fqr-form{max-width:760px;margin:0 auto;font-size:16px}
			.fqr-form fieldset{border:1px solid #d9d9d9;border-radius:8px;padding:16px;margin:0 0 16px}
			.fqr-form legend{font-weight:600;padding:0 6px}
			.fqr-form legend small{font-weight:400;color:#666}
			.fqr-row{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:10px}
			.fqr-row>label{flex:1 1 200px;display:flex;flex-direction:column;font-size:14px;gap:4px}
			.fqr-row>label.fqr-wide{flex-basis:100%}
			.fqr-form input[type=text],.fqr-form input[type=email],.fqr-form input[type=tel],.fqr-form input[type=date],.fqr-form input[type=number],.fqr-form select,.fqr-form textarea{width:100%;padding:8px 10px;border:1px solid #bbb;border-radius:6px;box-sizing:border-box;font:inherit}
			.fqr-pkg{display:grid;grid-template-columns:repeat(5,1fr) auto;gap:8px;align-items:end;margin-bottom:8px}
			.fqr-pkg label{display:flex;flex-direction:column;font-size:12px;gap:3px}
			.fqr-pkg button{height:36px}
			.fqr-checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:8px}
			.fqr-consent{display:block;font-size:14px}
			.fqr-add{margin:4px 0 12px;cursor:pointer}
			.fqr-submit{padding:12px 28px;font-size:16px;cursor:pointer}
			.fqr-submit[disabled]{opacity:.6;cursor:wait}
			.fqr-msg{margin-top:12px;padding:0;font-weight:500}
			.fqr-msg.ok{color:#116329}.fqr-msg.err{color:#b00020}
			.fqr-hp{position:absolute;left:-9999px;height:0;overflow:hidden}
			@media(max-width:640px){.fqr-pkg{grid-template-columns:repeat(2,1fr)}}
		</style>
		<script>
		(function(){
			var AJAX = <?php echo wp_json_encode( $ajax_url ); ?>;
			var T = <?php echo wp_json_encode( $i18n ); ?>;
			document.querySelectorAll('.fqr-form').forEach(function(form){
				var box = form.querySelector('.fqr-packages');
				var msg = form.querySelector('.fqr-msg');
				var btn = form.querySelector('.fqr-submit');
				var idx = 0;

				function field(label, name, i, attrs){
					return '<label>'+label+'<input type="number" name="pkg['+i+']['+name+']" '+attrs+' required></label>';
				}
				function addRow(){
					var i = idx++;
					var d = document.createElement('div');
					d.className = 'fqr-pkg';
					d.innerHTML =
						field(T.qty,'qty',i,'min="1" step="1" value="1"') +
						field(T.weight,'weight',i,'min="0.01" step="0.01"') +
						field(T.length,'length',i,'min="1" step="0.1"') +
						field(T.width,'width',i,'min="1" step="0.1"') +
						field(T.height,'height',i,'min="1" step="0.1"') +
						'<button type="button" class="fqr-del" title="'+T.remove+'">&times;</button>';
					box.appendChild(d);
				}
				addRow();

				form.querySelector('.fqr-add').addEventListener('click', addRow);
				box.addEventListener('click', function(e){
					if (e.target.classList.contains('fqr-del') && box.children.length > 1) {
						e.target.closest('.fqr-pkg').remove();
					}
				});

				form.addEventListener('submit', function(e){
					e.preventDefault();
					msg.className = 'fqr-msg'; msg.textContent = '';
					if (!form.checkValidity()) { form.reportValidity(); return; }
					btn.disabled = true;
					fetch(AJAX, {method:'POST', body:new FormData(form), credentials:'same-origin'})
						.then(function(r){ return r.json(); })
						.then(function(res){
							if (res && res.success) {
								msg.className = 'fqr-msg ok';
								msg.textContent = res.data.message;
								form.reset();
								box.innerHTML = ''; idx = 0; addRow();
							} else {
								msg.className = 'fqr-msg err';
								msg.textContent = (res && res.data && res.data.message) || T.error;
							}
						})
						.catch(function(){
							msg.className = 'fqr-msg err';
							msg.textContent = T.network;
						})
						.then(function(){ btn.disabled = false; });
				});
			});
		})();
		</script>
		<?php
		return ob_get_clean();
	}

	/* ------------------------------------------------------------------
	 * Form handling
	 * ----------------------------------------------------------------*/

	private static function fail( $message ) {
		wp_send_json_error( array( 'message' => self::t( $message ) ) );
	}

	private static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	private static function post( $key ) {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function ajax_submit() {
		// Language of the visitor's form (for messages and the customer email).
		self::$lang = ( 'ru' === self::post( 'lang' ) ) ? 'ru' : 'en';
		$lang       = self::$lang;

		if ( ! check_ajax_referer( 'fqr_submit', 'nonce', false ) ) {
			self::fail( 'Your session expired. Please reload the page and try again.' );
		}

		$s = self::settings();
		$success_text = ( 'ru' === $lang && $s['success_message_ru'] ) ? $s['success_message_ru'] : $s['success_message'];

		// Honeypot: pretend success so bots don't retry.
		if ( ! empty( $_POST['fqr_website'] ) ) {
			wp_send_json_success( array( 'message' => $success_text ) );
		}

		// Rate limit per IP.
		$ip     = self::client_ip();
		$rl_key = 'fqr_rl_' . md5( $ip );
		$count  = (int) get_transient( $rl_key );
		if ( $count >= (int) $s['max_per_hour'] ) {
			self::fail( 'Too many requests. Please try again later or contact us directly.' );
		}

		// Basic fields.
		$types = self::freight_types( 'en' );
		$ctry  = self::countries( 'en' );

		$freight_type = self::post( 'freight_type' );
		$o_country    = strtoupper( self::post( 'origin_country' ) );
		$d_country    = strtoupper( self::post( 'dest_country' ) );
		$o_city       = self::post( 'origin_city' );
		$d_city       = self::post( 'dest_city' );
		$o_post       = self::post( 'origin_postcode' );
		$d_post       = self::post( 'dest_postcode' );
		$cargo        = self::post( 'cargo_description' );
		$name         = self::post( 'contact_name' );
		$company      = self::post( 'company' );
		$email        = sanitize_email( self::post( 'email' ) );
		$phone        = self::post( 'phone' );
		$message      = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$consent      = ! empty( $_POST['consent'] ) ? 1 : 0; // phpcs:ignore WordPress.Security.NonceVerification

		$pickup = self::post( 'pickup_date' );
		if ( $pickup && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $pickup ) ) {
			$pickup = '';
		}

		if ( ! isset( $types[ $freight_type ] ) ) {
			self::fail( 'Please choose a valid freight type.' );
		}
		if ( ! isset( $ctry[ $o_country ] ) || ! isset( $ctry[ $d_country ] ) ) {
			self::fail( 'Please choose valid origin and destination countries.' );
		}
		if ( '' === $o_city || '' === $d_city || '' === $cargo || '' === $name ) {
			self::fail( 'Please fill in all required fields.' );
		}
		if ( ! is_email( $email ) ) {
			self::fail( 'Please enter a valid email address.' );
		}
		if ( ! $consent ) {
			self::fail( 'Please accept the consent checkbox.' );
		}

		// Extras (whitelist).
		$extras_all = self::extras_list( 'en' );
		$extras     = array();
		if ( ! empty( $_POST['extras'] ) && is_array( $_POST['extras'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			foreach ( wp_unslash( $_POST['extras'] ) as $e ) { // phpcs:ignore
				$e = sanitize_key( $e );
				if ( isset( $extras_all[ $e ] ) ) {
					$extras[] = $e;
				}
			}
		}

		// Packages.
		$raw_pkgs = ( isset( $_POST['pkg'] ) && is_array( $_POST['pkg'] ) ) ? wp_unslash( $_POST['pkg'] ) : array(); // phpcs:ignore
		if ( empty( $raw_pkgs ) || count( $raw_pkgs ) > 30 ) {
			self::fail( 'Please add at least one package.' );
		}

		$divisor = max( 1, (int) $s['volumetric_divisor'] );
		$pkgs    = array();
		$pieces  = 0;
		$weight  = 0.0;
		$volume  = 0.0; // m3.
		$vol_kg  = 0.0; // volumetric weight.

		foreach ( $raw_pkgs as $p ) {
			$qty = isset( $p['qty'] ) ? (int) $p['qty'] : 0;
			$w   = isset( $p['weight'] ) ? (float) $p['weight'] : 0;
			$l   = isset( $p['length'] ) ? (float) $p['length'] : 0;
			$wd  = isset( $p['width'] ) ? (float) $p['width'] : 0;
			$h   = isset( $p['height'] ) ? (float) $p['height'] : 0;

			if ( $qty < 1 || $qty > 10000 || $w <= 0 || $l <= 0 || $wd <= 0 || $h <= 0 || $w > 100000 || $l > 5000 || $wd > 5000 || $h > 5000 ) {
				self::fail( 'Please check package quantity, weight and dimensions.' );
			}

			$pkgs[]  = array(
				'qty'       => $qty,
				'weight_kg' => round( $w, 2 ),
				'length_cm' => round( $l, 1 ),
				'width_cm'  => round( $wd, 1 ),
				'height_cm' => round( $h, 1 ),
			);
			$pieces += $qty;
			$weight += $qty * $w;
			$volume += $qty * ( $l * $wd * $h ) / 1000000;
			$vol_kg += $qty * ( $l * $wd * $h ) / $divisor;
		}

		$chargeable = max( $weight, $vol_kg );

		// Save.
		global $wpdb;
		$reference = self::generate_reference();

		$ok = $wpdb->insert(
			self::table(),
			array(
				'reference'            => $reference,
				'created_at'           => current_time( 'mysql' ),
				'status'               => 'new',
				'lang'                 => $lang,
				'freight_type'         => $freight_type,
				'origin_country'       => $o_country,
				'origin_city'          => $o_city,
				'origin_postcode'      => $o_post,
				'dest_country'         => $d_country,
				'dest_city'            => $d_city,
				'dest_postcode'        => $d_post,
				'pickup_date'          => $pickup ? $pickup : null,
				'packages'             => wp_json_encode( $pkgs ),
				'total_pieces'         => $pieces,
				'total_weight_kg'      => round( $weight, 2 ),
				'total_volume_m3'      => round( $volume, 4 ),
				'chargeable_weight_kg' => round( $chargeable, 2 ),
				'cargo_description'    => $cargo,
				'extras'               => wp_json_encode( $extras ),
				'contact_name'         => $name,
				'company'              => $company,
				'email'                => $email,
				'phone'                => $phone,
				'message'              => $message,
				'currency'             => $s['currency'],
				'admin_notes'          => '',
				'ip_address'           => $ip,
				'consent'              => $consent,
			)
		);

		if ( false === $ok ) {
			self::fail( 'We could not save your request. Please try again or contact us directly.' );
		}

		set_transient( $rl_key, $count + 1, HOUR_IN_SECONDS );

		$row = self::get_request( (int) $wpdb->insert_id );
		self::send_emails( $row );

		/**
		 * Fires after a quote request is stored. Phase 2 hook: call carrier APIs here.
		 *
		 * @param object $row Database row.
		 */
		do_action( 'fqr_request_created', $row );

		wp_send_json_success( array(
			'message'   => $success_text . ' (' . self::t( 'Reference' ) . ': ' . $reference . ')',
			'reference' => $reference,
		) );
	}

	private static function generate_reference() {
		global $wpdb;
		do {
			$ref    = 'FQ-' . gmdate( 'ymd' ) . '-' . strtoupper( wp_generate_password( 4, false, false ) );
			$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE reference = %s', $ref ) ); // phpcs:ignore
		} while ( $exists );
		return $ref;
	}

	public static function get_request( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) ); // phpcs:ignore
	}

	/* ------------------------------------------------------------------
	 * Emails (team = English, customer = language of the form they used)
	 * ----------------------------------------------------------------*/

	private static function summary_text( $r, $lang = 'en' ) {
		$t      = function ( $s ) use ( $lang ) {
			return self::t( $s, $lang );
		};
		$types  = self::freight_types( $lang );
		$all    = self::extras_list( $lang );
		$extras = array();
		foreach ( (array) json_decode( $r->extras, true ) as $e ) {
			$extras[] = isset( $all[ $e ] ) ? $all[ $e ] : $e;
		}

		$lines   = array();
		$lines[] = $t( 'Reference' ) . ': ' . $r->reference;
		$lines[] = $t( 'Freight type' ) . ': ' . ( isset( $types[ $r->freight_type ] ) ? $types[ $r->freight_type ] : $r->freight_type );
		$lines[] = $t( 'From' ) . ': ' . trim( $r->origin_postcode . ' ' . $r->origin_city ) . ', ' . self::country_name( $r->origin_country, $lang );
		$lines[] = $t( 'To' ) . ': ' . trim( $r->dest_postcode . ' ' . $r->dest_city ) . ', ' . self::country_name( $r->dest_country, $lang );
		$lines[] = $t( 'Pickup date' ) . ': ' . ( $r->pickup_date ? $r->pickup_date : '-' );
		$lines[] = $t( 'Cargo' ) . ': ' . $r->cargo_description;
		$lines[] = '';
		$lines[] = $t( 'Packages' ) . ':';
		foreach ( (array) json_decode( $r->packages, true ) as $p ) {
			$lines[] = sprintf( '  %d x %s %s, %s x %s x %s %s', $p['qty'], $p['weight_kg'], $t( 'kg' ), $p['length_cm'], $p['width_cm'], $p['height_cm'], $t( 'cm' ) );
		}
		$lines[] = sprintf( '%s: %d %s, %s %s, %s m3, %s %s %s', $t( 'Totals' ), $r->total_pieces, $t( 'pcs' ), $r->total_weight_kg, $t( 'kg' ), $r->total_volume_m3, $t( 'chargeable' ), $r->chargeable_weight_kg, $t( 'kg' ) );
		$lines[] = $t( 'Extras' ) . ': ' . ( $extras ? implode( ', ', $extras ) : '-' );
		return implode( "\n", $lines );
	}

	private static function send_emails( $r ) {
		$s = self::settings();

		// To the team (always English).
		$body  = "New freight quote request (form language: " . strtoupper( $r->lang ) . ")\n\n";
		$body .= self::summary_text( $r, 'en' ) . "\n\n";
		$body .= "Contact:\n";
		$body .= '  Name:    ' . $r->contact_name . "\n";
		$body .= '  Company: ' . $r->company . "\n";
		$body .= '  Email:   ' . $r->email . "\n";
		$body .= '  Phone:   ' . $r->phone . "\n";
		$body .= '  Comment: ' . $r->message . "\n\n";
		$body .= 'Open in admin: ' . admin_url( 'admin.php?page=fqr&view=' . (int) $r->id ) . "\n";

		$headers = array( 'Reply-To: ' . $r->contact_name . ' <' . $r->email . '>' );
		wp_mail( $s['notify_email'], '[Quote request] ' . $r->reference . ' ' . $r->origin_country . ' → ' . $r->dest_country, $body, $headers );

		// Confirmation to the customer (in their language).
		if ( ! empty( $s['customer_copy'] ) ) {
			$lang = ( 'ru' === $r->lang ) ? 'ru' : 'en';
			$c    = self::t( 'Hello', $lang ) . ' ' . $r->contact_name . ",\n\n";
			$c   .= self::t( 'Thank you for your request. We will prepare your quote and get back to you shortly.', $lang ) . "\n\n";
			$c   .= self::summary_text( $r, $lang ) . "\n\n";
			$c   .= get_bloginfo( 'name' ) . "\n";
			wp_mail( $r->email, self::t( 'We received your quote request', $lang ) . ' ' . $r->reference, $c );
		}
	}

	/* ------------------------------------------------------------------
	 * Admin (English only)
	 * ----------------------------------------------------------------*/

	public static function admin_menu() {
		add_menu_page( 'Freight Quotes', 'Freight Quotes', 'manage_options', 'fqr', array( __CLASS__, 'page_router' ), 'dashicons-airplane', 26 );
		add_submenu_page( 'fqr', 'All requests', 'All requests', 'manage_options', 'fqr', array( __CLASS__, 'page_router' ) );
		add_submenu_page( 'fqr', 'Settings', 'Settings', 'manage_options', 'fqr-settings', array( __CLASS__, 'page_settings' ) );
	}

	public static function page_router() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( isset( $_GET['view'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			self::page_detail( (int) $_GET['view'] ); // phpcs:ignore
		} else {
			self::page_list();
		}
	}

	private static function page_list() {
		global $wpdb;
		$table    = self::table();
		$statuses = self::statuses();
		$types    = self::freight_types( 'en' );
		$filter   = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore
		$paged    = max( 1, isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 ); // phpcs:ignore
		$per      = 20;
		$offset   = ( $paged - 1 ) * $per;

		if ( $filter && isset( $statuses[ $filter ] ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", $filter ) ); // phpcs:ignore
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE status = %s ORDER BY id DESC LIMIT %d OFFSET %d", $filter, $per, $offset ) ); // phpcs:ignore
		} else {
			$filter = '';
			$total  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore
			$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY id DESC LIMIT %d OFFSET %d", $per, $offset ) ); // phpcs:ignore
		}
		$counts = $wpdb->get_results( "SELECT status, COUNT(*) c FROM $table GROUP BY status", OBJECT_K ); // phpcs:ignore
		$base   = admin_url( 'admin.php?page=fqr' );
		?>
		<div class="wrap">
			<h1>Freight quote requests</h1>
			<ul class="subsubsub">
				<li><a href="<?php echo esc_url( $base ); ?>" class="<?php echo $filter ? '' : 'current'; ?>">All</a> |</li>
				<?php
				$i = 0;
				foreach ( $statuses as $k => $label ) :
					$i++;
					$c = isset( $counts[ $k ] ) ? (int) $counts[ $k ]->c : 0;
					?>
					<li><a href="<?php echo esc_url( add_query_arg( 'status', $k, $base ) ); ?>" class="<?php echo $filter === $k ? 'current' : ''; ?>"><?php echo esc_html( $label ); ?> <span class="count">(<?php echo (int) $c; ?>)</span></a><?php echo $i < count( $statuses ) ? ' |' : ''; ?></li>
				<?php endforeach; ?>
			</ul>
			<table class="wp-list-table widefat fixed striped" style="margin-top:12px">
				<thead><tr>
					<th style="width:130px">Reference</th><th style="width:130px">Date</th><th>Customer</th>
					<th>Route</th><th style="width:110px">Type</th><th style="width:120px">Chargeable</th>
					<th style="width:80px">Status</th><th style="width:100px">Quoted</th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="8">No requests yet.</td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( add_query_arg( 'view', (int) $r->id, $base ) ); ?>"><strong><?php echo esc_html( $r->reference ); ?></strong></a> <small>[<?php echo esc_html( strtoupper( $r->lang ) ); ?>]</small></td>
						<td><?php echo esc_html( mysql2date( 'Y-m-d H:i', $r->created_at ) ); ?></td>
						<td><?php echo esc_html( $r->contact_name ); ?><?php echo $r->company ? '<br><small>' . esc_html( $r->company ) . '</small>' : ''; ?></td>
						<td><?php echo esc_html( $r->origin_city . ' (' . $r->origin_country . ') → ' . $r->dest_city . ' (' . $r->dest_country . ')' ); ?></td>
						<td><?php echo esc_html( isset( $types[ $r->freight_type ] ) ? $types[ $r->freight_type ] : $r->freight_type ); ?></td>
						<td><?php echo esc_html( $r->chargeable_weight_kg ); ?> kg</td>
						<td><?php echo esc_html( isset( $statuses[ $r->status ] ) ? $statuses[ $r->status ] : $r->status ); ?></td>
						<td><?php echo null !== $r->quoted_price ? esc_html( number_format_i18n( $r->quoted_price, 2 ) . ' ' . $r->currency ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php
			$pages = (int) ceil( $total / $per );
			if ( $pages > 1 ) {
				echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array(
					'base'      => add_query_arg( 'paged', '%#%' ),
					'format'    => '',
					'current'   => $paged,
					'total'     => $pages,
					'prev_text' => '‹',
					'next_text' => '›',
				) ) ) . '</div></div>';
			}
			?>
		</div>
		<?php
	}

	private static function page_detail( $id ) {
		$back = admin_url( 'admin.php?page=fqr' );

		// Handle delete.
		if ( isset( $_GET['delete'] ) && check_admin_referer( 'fqr_delete_' . $id ) ) { // phpcs:ignore
			global $wpdb;
			$wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
			wp_safe_redirect( add_query_arg( 'deleted', 1, $back ) );
			exit;
		}

		// Handle update.
		$saved = false;
		if ( isset( $_POST['fqr_update'] ) && check_admin_referer( 'fqr_update_' . $id ) ) {
			global $wpdb;
			$statuses = self::statuses();
			$status   = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'new';
			if ( ! isset( $statuses[ $status ] ) ) {
				$status = 'new';
			}
			$price_raw = isset( $_POST['quoted_price'] ) ? trim( wp_unslash( $_POST['quoted_price'] ) ) : '';
			$price     = ( '' === $price_raw ) ? null : round( (float) str_replace( ',', '.', $price_raw ), 2 );
			$currency  = isset( $_POST['currency'] ) ? strtoupper( substr( sanitize_text_field( wp_unslash( $_POST['currency'] ) ), 0, 3 ) ) : 'EUR';
			$notes     = isset( $_POST['admin_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['admin_notes'] ) ) : '';

			$wpdb->update(
				self::table(),
				array(
					'status'       => $status,
					'quoted_price' => $price,
					'currency'     => $currency,
					'admin_notes'  => $notes,
				),
				array( 'id' => $id )
			);
			$saved = true;
		}

		$r = self::get_request( $id );
		if ( ! $r ) {
			echo '<div class="wrap"><h1>Request not found</h1><p><a href="' . esc_url( $back ) . '">← Back</a></p></div>';
			return;
		}

		$types    = self::freight_types( 'en' );
		$statuses = self::statuses();
		$extras_a = self::extras_list( 'en' );
		$extras   = array();
		foreach ( (array) json_decode( $r->extras, true ) as $e ) {
			$extras[] = isset( $extras_a[ $e ] ) ? $extras_a[ $e ] : $e;
		}
		$subject = rawurlencode( 'Your quote ' . $r->reference );
		?>
		<div class="wrap">
			<h1>Request <?php echo esc_html( $r->reference ); ?></h1>
			<p><a href="<?php echo esc_url( $back ); ?>">← All requests</a></p>
			<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>Saved.</p></div><?php endif; ?>

			<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">
				<div style="flex:2 1 460px">
					<table class="widefat striped">
						<tbody>
						<tr><th style="width:170px">Received</th><td><?php echo esc_html( mysql2date( 'Y-m-d H:i', $r->created_at ) ); ?></td></tr>
						<tr><th>Customer language</th><td><?php echo esc_html( 'ru' === $r->lang ? 'Russian (RU)' : 'English (EN)' ); ?></td></tr>
						<tr><th>Freight type</th><td><?php echo esc_html( isset( $types[ $r->freight_type ] ) ? $types[ $r->freight_type ] : $r->freight_type ); ?></td></tr>
						<tr><th>From</th><td><?php echo esc_html( trim( $r->origin_postcode . ' ' . $r->origin_city ) . ', ' . self::country_name( $r->origin_country, 'en' ) ); ?></td></tr>
						<tr><th>To</th><td><?php echo esc_html( trim( $r->dest_postcode . ' ' . $r->dest_city ) . ', ' . self::country_name( $r->dest_country, 'en' ) ); ?></td></tr>
						<tr><th>Pickup date</th><td><?php echo esc_html( $r->pickup_date ? $r->pickup_date : '—' ); ?></td></tr>
						<tr><th>Cargo</th><td><?php echo esc_html( $r->cargo_description ); ?></td></tr>
						<tr><th>Packages</th><td>
							<?php foreach ( (array) json_decode( $r->packages, true ) as $p ) : ?>
								<?php echo esc_html( sprintf( '%d × %s kg, %s × %s × %s cm', $p['qty'], $p['weight_kg'], $p['length_cm'], $p['width_cm'], $p['height_cm'] ) ); ?><br>
							<?php endforeach; ?>
						</td></tr>
						<tr><th>Totals</th><td><?php echo esc_html( sprintf( '%d pcs · %s kg · %s m³', $r->total_pieces, $r->total_weight_kg, $r->total_volume_m3 ) ); ?></td></tr>
						<tr><th>Chargeable weight</th><td><strong><?php echo esc_html( $r->chargeable_weight_kg ); ?> kg</strong></td></tr>
						<tr><th>Extras</th><td><?php echo esc_html( $extras ? implode( ', ', $extras ) : '—' ); ?></td></tr>
						<tr><th>Customer</th><td>
							<?php echo esc_html( $r->contact_name ); ?><?php echo $r->company ? ' · ' . esc_html( $r->company ) : ''; ?><br>
							<a href="mailto:<?php echo esc_attr( $r->email ); ?>?subject=<?php echo esc_attr( $subject ); ?>"><?php echo esc_html( $r->email ); ?></a>
							<?php echo $r->phone ? '<br>' . esc_html( $r->phone ) : ''; ?>
						</td></tr>
						<tr><th>Comment</th><td><?php echo nl2br( esc_html( $r->message ? $r->message : '—' ) ); ?></td></tr>
						<tr><th>IP</th><td><?php echo esc_html( $r->ip_address ); ?></td></tr>
						</tbody>
					</table>
				</div>

				<div style="flex:1 1 280px">
					<form method="post" class="postbox" style="padding:16px">
						<?php wp_nonce_field( 'fqr_update_' . $id ); ?>
						<h2 style="margin-top:0">Quote &amp; status</h2>
						<p><label>Status<br>
							<select name="status">
								<?php foreach ( $statuses as $k => $label ) : ?>
									<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $r->status, $k ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select></label></p>
						<p><label>Quoted price (incl. your margin)<br>
							<input type="text" name="quoted_price" value="<?php echo null !== $r->quoted_price ? esc_attr( $r->quoted_price ) : ''; ?>" style="width:60%">
							<input type="text" name="currency" value="<?php echo esc_attr( $r->currency ); ?>" maxlength="3" style="width:25%"></label></p>
						<p><label>Internal notes (carrier cost, margin, etc.)<br>
							<textarea name="admin_notes" rows="6" style="width:100%"><?php echo esc_textarea( $r->admin_notes ); ?></textarea></label></p>
						<p><button type="submit" name="fqr_update" value="1" class="button button-primary">Save</button>
							<a class="button" href="mailto:<?php echo esc_attr( $r->email ); ?>?subject=<?php echo esc_attr( $subject ); ?>">Email customer</a></p>
					</form>
					<p><a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'view' => $id, 'delete' => 1 ), $back ), 'fqr_delete_' . $id ) ); ?>" onclick="return confirm('Delete this request permanently?');" style="color:#b32d2e">Delete request</a></p>
				</div>
			</div>
		</div>
		<?php
	}

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$saved = false;
		if ( isset( $_POST['fqr_save_settings'] ) && check_admin_referer( 'fqr_settings' ) ) {
			$new = array(
				'notify_email'       => sanitize_email( wp_unslash( $_POST['notify_email'] ?? '' ) ),
				'customer_copy'      => ! empty( $_POST['customer_copy'] ) ? 1 : 0,
				'volumetric_divisor' => max( 1, (int) ( $_POST['volumetric_divisor'] ?? 5000 ) ),
				'max_per_hour'       => max( 1, (int) ( $_POST['max_per_hour'] ?? 5 ) ),
				'currency'           => strtoupper( substr( sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'EUR' ) ), 0, 3 ) ),
				'privacy_url'        => esc_url_raw( wp_unslash( $_POST['privacy_url'] ?? '' ) ),
				'privacy_url_ru'     => esc_url_raw( wp_unslash( $_POST['privacy_url_ru'] ?? '' ) ),
				'success_message'    => sanitize_text_field( wp_unslash( $_POST['success_message'] ?? '' ) ),
				'success_message_ru' => sanitize_text_field( wp_unslash( $_POST['success_message_ru'] ?? '' ) ),
			);
			if ( ! is_email( $new['notify_email'] ) ) {
				$new['notify_email'] = get_option( 'admin_email' );
			}
			update_option( self::OPT, $new );
			$saved = true;
		}
		$s = self::settings();
		?>
		<div class="wrap">
			<h1>Freight Quotes – Settings</h1>
			<?php if ( $saved ) : ?><div class="notice notice-success is-dismissible"><p>Settings saved.</p></div><?php endif; ?>
			<form method="post">
				<?php wp_nonce_field( 'fqr_settings' ); ?>
				<table class="form-table" role="presentation">
					<tr><th>Notification email</th><td><input type="email" name="notify_email" value="<?php echo esc_attr( $s['notify_email'] ); ?>" class="regular-text"></td></tr>
					<tr><th>Send copy to customer</th><td><label><input type="checkbox" name="customer_copy" value="1" <?php checked( $s['customer_copy'] ); ?>> Yes</label></td></tr>
					<tr><th>Volumetric divisor</th><td><input type="number" name="volumetric_divisor" value="<?php echo esc_attr( $s['volumetric_divisor'] ); ?>" min="1"> <p class="description">cm³ per kg. 5000 for express/air, 3000 for some road freight. Chargeable weight = max(actual, volumetric).</p></td></tr>
					<tr><th>Default currency</th><td><input type="text" name="currency" value="<?php echo esc_attr( $s['currency'] ); ?>" maxlength="3" size="4"></td></tr>
					<tr><th>Max requests per IP / hour</th><td><input type="number" name="max_per_hour" value="<?php echo esc_attr( $s['max_per_hour'] ); ?>" min="1"></td></tr>
					<tr><th>Privacy policy URL (EN)</th><td><input type="url" name="privacy_url" value="<?php echo esc_attr( $s['privacy_url'] ); ?>" class="regular-text"></td></tr>
					<tr><th>Privacy policy URL (RU)</th><td><input type="url" name="privacy_url_ru" value="<?php echo esc_attr( $s['privacy_url_ru'] ); ?>" class="regular-text"></td></tr>
					<tr><th>Success message (EN)</th><td><input type="text" name="success_message" value="<?php echo esc_attr( $s['success_message'] ); ?>" class="large-text"></td></tr>
					<tr><th>Success message (RU)</th><td><input type="text" name="success_message_ru" value="<?php echo esc_attr( $s['success_message_ru'] ); ?>" class="large-text"></td></tr>
				</table>
				<p class="submit"><button type="submit" name="fqr_save_settings" value="1" class="button button-primary">Save settings</button></p>
			</form>
			<p>Shortcode: <code>[freight_quote_form]</code> (language detected automatically) or <code>[freight_quote_form lang="ru"]</code> / <code>[freight_quote_form lang="en"]</code> to force a language.</p>
		</div>
		<?php
	}
}

FQR_Plugin::init();
